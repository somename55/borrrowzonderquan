package com.example.borrow;

public class User {

    private String ID;
    private String UserName;
    private String UserTrust;
    private int UserAge;


}