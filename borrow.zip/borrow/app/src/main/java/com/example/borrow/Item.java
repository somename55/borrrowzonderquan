package com.example.borrow;

public class Item {
    private String ItemName;
    private String ItemCategorie;
    private String ItemDescription;


    public Item(String fItem, String fCat, String fDes){
        ItemName = fItem;
        ItemCategorie = fCat;
        ItemDescription = fDes;

    }

    public String getItem() {
        return ItemName;
    }

    public String getItemCategorie() {
        return ItemCategorie;
    }

    public String getItemDescription() {
        return ItemDescription;
    }


}
